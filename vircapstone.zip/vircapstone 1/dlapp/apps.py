from django.apps import AppConfig
from django.conf import settings
from keras.models import load_model
import os

class DlappConfig(AppConfig):
    name = 'dlapp'
    path1 = os.path.join(settings.MODEL,'final_model1.h5')
    #predictor = load_model('final_model1.h5')
    predictor = load_model(path1)
    print('Hi')
